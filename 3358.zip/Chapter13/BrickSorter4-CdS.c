//*!!Sensor,    S1,              I2cPort, sensorI2CCustom,      ,                !!*//
//*!!Sensor,    S2,         BlockPresent, sensorTouch,      ,                    !!*//
//*!!                                                                            !!*//
//*!!Start automatically generated configuration code.                           !!*//
const tSensors I2cPort              = (tSensors) S1;   //sensorI2CCustom    //*!!!!*//
const tSensors BlockPresent         = (tSensors) S2;   //sensorTouch        //*!!!!*//
//*!!CLICK to edit 'wizard' created sensor & motor configuration.                !!*//
// PCF8574 constants
	const ubyte I2cAddr8574 = 0x40;

	byte I2cMessageLeds[3] = {2, I2cAddr8574, 0xff};

// I2c Read buffer
  byte buf[2];

// CheckI2C waits up to 100ms for I2C ready.
// Stops in error if timeout

void CheckI2C()
{
	int i;
	for(i=0; i<50; i++)
	{
	  if (nI2CStatus[I2cPort] != NO_ERR)
			wait1Msec(2);
		else
		  break;
	}
	if(i>49)
	{
  	eraseDisplay();
  	nxtDisplayTextLine(3, "ErrI2c");
  	PlaySound(soundBeepBeep);
  	wait1Msec(1000);
	  StopAllTasks();
	}
}


// Initialisation of I2C

void InitI2C()
{
// Set sensor type to non-I2C to reinit sensor
  SensorType [I2cPort] = sensorLightInactive;
	wait1Msec(100);

// Set sensor type to I2C
  SensorType [I2cPort] = sensorI2CCustom;
	wait1Msec(100);

// Switch off leds
	sendI2CMsg (I2cPort, I2cMessageLeds[0], 0);
	wait1Msec(100);

// Empty I2C input fifo	if not empty
	if(nI2CBytesReady[I2cPort]>0)
  	readI2CReply(I2cPort, buf[0], nI2CBytesReady[I2cPort]);

}

// Read reflected color, one LED is lit.
// Led = 1 -> Blue
// Led = 4 -> Red
// Led = 0x10 -> Green
// Led = 0 -> Background (no led lit)

int ReadColorComponent(int Led)
{
	int Light;
// Light Led
	I2cMessageLeds[2] = ~(Led);
	sendI2CMsg (I2cPort, I2cMessageLeds[0], 0);
	CheckI2C(); // Wait for I2c command complete

// Switch back to non-I2C sensor to read photoresistor
// (RobotC does not allow reading raw value in current version)

  SensorType [I2cPort] = sensorLightInactive;
	wait1Msec(20);
// Read reflected value
	Light = 1024-SensorRaw[I2cPort];

// Set sensor type back to I2C
  SensorType [I2cPort] = sensorI2CCustom;
	wait1Msec(20);
	return Light;
}

int max(int a, int b)
{
	return (a>b)?a:b;
}

int min(int a, int b)
{
	return (a<b)?a:b;
}

int ReadHue()
{
	int Red, Green, Blue;
	int RedN, GreenN, BlueN;
	int Hue;

	int MaxIntens, MinIntens, DiffIntens;

// Read all components and scale them
	Blue = ReadColorComponent(1)*10;
	Red = ReadColorComponent(4)*10;
	Green = ReadColorComponent(0x10)*10;
	ReadColorComponent(0); // Light off
	nxtDisplayTextLine(1,"%d", Blue);
	nxtDisplayTextLine(2,"%d", Red);
	nxtDisplayTextLine(3,"%d", Green);
	MaxIntens = max( max(Blue, Red), Green);
	MinIntens = min( min(Blue, Red), Green);
	DiffIntens = (MaxIntens - MinIntens)/60;

	RedN = (MaxIntens-Red)/DiffIntens;
	GreenN = (MaxIntens-Green)/DiffIntens;
	BlueN = (MaxIntens-Blue)/DiffIntens;

	if(Blue == MaxIntens) Hue = 240 + GreenN - RedN;
	if(Green == MaxIntens) Hue = 120 + RedN - BlueN;
	if(Red == MaxIntens) Hue = BlueN - GreenN;
	if(Hue<0) Hue=Hue+360;

	return Hue;
}

void T56RaiseArm(int angle)
{
	int TargetAngle;
	nMotorEncoderTarget[motorB] = angle;
	TargetAngle = nMotorEncoder[motorB]+angle;
	motor[motorB]=100;
	while(abs(TargetAngle-nMotorEncoder[motorB])>3);
	wait1Msec(100);
}

void T56DownArm(int angle)
{
	int TargetAngle;
	nMotorEncoderTarget[motorB] = angle;
	TargetAngle = nMotorEncoder[motorB]-angle;
	motor[motorB]=-100;
	while(abs(TargetAngle-nMotorEncoder[motorB])>3);
	wait1Msec(100);
}

void T56RotateTo(int angle)
{
	int TargetAngle;
	int DeltaAngle;

	TargetAngle = angle*168; // mechanical 168x downgearing
	DeltaAngle = TargetAngle-nMotorEncoder[motorC];
	if(DeltaAngle > 0)
	{
		nMotorEncoderTarget[motorC] = DeltaAngle;
		motor[motorC] = 100;
	}
	else
	{
		nMotorEncoderTarget[motorC] = -DeltaAngle;
		motor[motorC] = -100;
	}
	while(abs(TargetAngle-nMotorEncoder[motorC])>5);
	wait1Msec(200);
}

void T56OpenClaw()
{
	motor[motorA]=-70;
	wait1Msec(500);
	motor[motorA]=-15;
}

void T56CloseClaw()
{
	motor[motorA]=70;
	wait1Msec(500);
	motor[motorA]=15;
}


const int BinAngle = 30;

task main()
{

	int Hue;

	InitI2C();

	T56RotateTo(BinAngle);
	while(true)
	{
		PlaySound(soundBeepBeep);
		while(SensorValue(BlockPresent)==0);
		wait1Msec(300);
		nxtDisplayTextLine(5, "Hue: %d", Hue=ReadHue());
		T56RaiseArm(1000);
		T56RotateTo(0);
		T56DownArm(1000);
		T56CloseClaw();
		wait1Msec(500);
		T56RaiseArm(1000);
		if(Hue>330 | Hue<20)
		{
			T56RotateTo(-2*BinAngle);
			nxtDisplayTextLine(7, "Red");
		}
		else if(Hue<80)
		{
			T56RotateTo(-BinAngle);
			nxtDisplayTextLine(7, "Yellow");
		}
		else if(Hue<180)
		{
			T56RotateTo(BinAngle);
			nxtDisplayTextLine(7, "Green");
		}
		else if(Hue<245)
		{
			T56RotateTo(2*BinAngle);
			nxtDisplayTextLine(7, "Blue");
		}
		else if(Hue<330)
		{
			T56RotateTo(3*BinAngle);
			nxtDisplayTextLine(7, "Purple");
		}
		T56DownArm(4000);
		T56OpenClaw();
		T56RaiseArm(3000);
		while(SensorValue(BlockPresent)==1);
	}
}
