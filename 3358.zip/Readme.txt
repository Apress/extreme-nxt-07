Extreme NXT
by Michael Gasperi and Phillip Hurbain with Isabelle Hurbain
2/16/2007
ISBN 1590598180

Notes:
1. NXT-G MyBlocks must be moved to the proper ...Default\Blocks\MyBlocks directory to work.
2. Make sure you are running at least NXT Firmware 1.04.


