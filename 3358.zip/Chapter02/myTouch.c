//*!!Sensor,    S1,                touch, sensorTouch,                           !!*//
//*!!                                                                            !!*//
//*!!Start automatically generated configuration code.                           !!*//
const tSensors touch                = (tSensors) S1;

task main()
{
	eraseDisplay();
	while (true)
	{
	  if (SensorBoolean[touch])
	  {
			nxtDisplayTextLine(5, "Pressed    ");
		}
		else
			nxtDisplayTextLine(5, "Not Pressed");
	}
}
