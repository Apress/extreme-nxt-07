//*!!Sensor,    S1,              I2cPort, sensorI2CCustom,      ,                !!*//
//*!!Sensor,    S2,         BlockPresent, sensorTouch,      ,                    !!*//
//*!!                                                                            !!*//
//*!!Start automatically generated configuration code.                           !!*//
const tSensors I2cPort              = (tSensors) S1;   //sensorI2CCustom    //*!!!!*//
const tSensors BlockPresent         = (tSensors) S2;   //sensorTouch        //*!!!!*//
//*!!CLICK to edit 'wizard' created sensor & motor configuration.                !!*//

// TSL2550 constants
	const ubyte I2cAddr2550 = 0x72;
	const ubyte PowerUp = 0x03;
	const ubyte PowerDn = 0x00;
	const ubyte ReadVisible = 0x43;
	const ubyte ReadIR = 0x83;
	const ubyte SetDimRange = 0x18;
	const ubyte SetBrightRange = 0x1d;


// PCF8574 constants
	const ubyte I2cAddr8574 = 0x40;

	int I2cMessageLeds[3] = {2, I2cAddr8574, 0xff};

// Chord values table
	const int ChordVal[8]={0, 16, 49, 115, 247, 511, 1039, 2095};

// Write command buffers. Last byte = TSL2550 command
  int I2cMessagePdn[3] = {2, I2cAddr2550, PowerDn};
  int I2cMessageWake[3] = {2, I2cAddr2550, PowerUp};
  int I2cMessageRead[3] = {2, I2cAddr2550, ReadVisible};
  int I2cMessageSetDimRange[3] = {2, I2cAddr2550, SetDimRange};
  int I2cMessageSetBrightRange[3] = {2, I2cAddr2550, SetBrightRange};

// I2c Read buffer
  int buf[2];

// Prototypes
/*	void CheckI2C();
	void InitI2C();
	int ReadHue();
	int max(int a, int b);
*/

// CheckI2C waits up to 100ms for I2C ready.
// Stops in error if timeout

void CheckI2C()
{
	int i;
	for(i=0; i<50; i++)
	{
	  if (nI2CStatus[I2cPort] != NO_ERR)
			wait1Msec(2);
		else
		  break;
	}
	if(i>49)
	{
  	eraseDisplay();
  	nxtDisplayTextLine(3, "ErrI2c");
  	PlaySound(soundBeepBeep);
  	wait1Msec(1000);
	  StopAllTasks();
	}
}




// Initialisation of I2C and of TSL2550

void InitI2C()
{
// Set sensor type to non-I2C to reinit sensor
  SensorType [I2cPort] = sensorLightInactive;
	wait1Msec(100);

// Set sensor type to I2C
  SensorType [I2cPort] = sensorI2CCustom;
	wait1Msec(100);

// Send wake-up command to TSL2550
	sendI2CMsg (I2cPort, I2cMessageWake[0], 0);
	wait1Msec(100);
// Switch to fast, low wensitivity mode
	sendI2CMsg (I2cPort, I2cMessageSetBrightRange[0], 0);

// Switch off leds
	sendI2CMsg (I2cPort, I2cMessageLeds[0], 0);
	wait1Msec(100);

// Empty I2C input fifo	if not empty
	if(nI2CBytesReady[I2cPort]>0)
  	readI2CReply(I2cPort, buf[0], nI2CBytesReady[I2cPort]);

}

// Read reflected color, one LED is lit.
// Led = 1 -> Blue
// Led = 4 -> Red
// Led = 0x10 -> Green
// Led = 0 -> Background (no led lit)

int ReadColorComponent(int Led)
{
	int light;
	int chord;

// Light Led
	I2cMessageLeds[2] = ~(Led);
	sendI2CMsg (I2cPort, I2cMessageLeds[0], 0);
	CheckI2C(); // Wait for I2c command complete

// Reset 2550 sensor to start conversion
	sendI2CMsg (I2cPort, I2cMessagePdn[0], 0);
	CheckI2C();
	sendI2CMsg (I2cPort, I2cMessageWake[0], 0);
 	CheckI2C();

// We read visible light channel
 	I2cMessageRead[2]=ReadVisible;
	do
	{
// Send read command
 		sendI2CMsg(I2cPort, I2cMessageRead[0], 1);
		CheckI2C();
// Read value
		readI2CReply(I2cPort, buf[0], 1);
	}while ((buf[0] & 0x80)==0) // Read till valid

// convert encoded value
	chord = (buf[0]& 0x70)>>4;
	light = ChordVal[chord] + (1<<chord)*(buf[0]&0xf);
	return light;
}

int max(int a, int b)
{
	return (a>b)?a:b;
}

int min(int a, int b)
{
	return (a<b)?a:b;
}

int ReadHue()
{
	int Red, Green, Blue;
	int RedN, GreenN, BlueN;
	int Hue;

	int MaxIntens, MinIntens, DiffIntens;

// Read all components and scale them
	Blue = ReadColorComponent(1)*100;
	Red = ReadColorComponent(4)*100;
	Green = ReadColorComponent(0x10)*100;
	ReadColorComponent(0); // Light off
	nxtDisplayTextLine(1,"%d", Blue);
	nxtDisplayTextLine(2,"%d", Red);
	nxtDisplayTextLine(3,"%d", Green);
	MaxIntens = max( max(Blue, Red), Green);
	MinIntens = min( min(Blue, Red), Green);
	DiffIntens = (MaxIntens - MinIntens)/60;

	RedN = (MaxIntens-Red)/DiffIntens;
	GreenN = (MaxIntens-Green)/DiffIntens;
	BlueN = (MaxIntens-Blue)/DiffIntens;

	if(Blue == MaxIntens) Hue = 240 + GreenN - RedN;
	if(Green == MaxIntens) Hue = 120 + RedN - BlueN;
	if(Red == MaxIntens) Hue = BlueN - GreenN;
	if(Hue<0) Hue=Hue+360;

	return Hue;
}

task main()
{

	int i;

	InitI2C();


	while(true)
	{
		while(SensorValue(BlockPresent)==0);
		wait1Msec(300);
		nxtDisplayTextLine(7, "Hue: %d", ReadHue());
		while(SensorValue(BlockPresent)==1);
	}
}
